/*
 * LDR_cfg.h
 *
 *  Created on: 12 Sep 2022
 *      Author: 20109
 */

#ifndef HAL_LDR_LDR_CFG_H_
#define HAL_LDR_LDR_CFG_H_

#define LDR_PORT     ADC_PORT
#define LDR_CHANNEL  ADC0_ID

#endif /* HAL_LDR_LDR_CFG_H_ */
