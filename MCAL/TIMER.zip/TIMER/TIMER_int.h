/*********************************************************/
/***********		Author: TaqiEldeen	 	**************/
/***********		Layer: MCAL			 	**************/
/***********		Component: TIMER		**************/
/***********		Version: 1.00		 	**************/
/***********		Date: 13 Sep 2022	 	**************/
/*********************************************************/

#ifndef MCAL_TIMER_TIMER_INT_H_
#define MCAL_TIMER_TIMER_INT_H_

typedef enum {
	TIMER0_ID,
	TIMER1_ID,
	TIMER2_ID
};


#define	TIMER_DUTY_CYCLE_25		25
#define	TIMER_DUTY_CYCLE_50		50
#define	TIMER_DUTY_CYCLE_75		75
#define	TIMER_DUTY_CYCLE_100	100

/**********************************************************************************************************
 * Description : Interface Function to 1-prescaler select, 2-Timer mode select, 3-Set OC0 Pin state
 * Outputs     : void
 * Inputs      : void
 ***********************************************************************************************************/
void TIMER_vInit ();

/**********************************************************************************************************
 * Description : Interface Function to set a delay for a specific timer
 * Outputs     : The counts of OVF
 * Inputs      : Timer ID, required delay in milliseconds
 ***********************************************************************************************************/
void TIMER_vTurnOn			(u8 A_u8TimerId);

/**********************************************************************************************************
 * Description : Interface Function to set a delay for a specific timer
 * Outputs     : The counts of OVF
 * Inputs      : Timer ID, required delay in milliseconds
 ***********************************************************************************************************/
void TIMER_vTurnOff			(u8 A_u8TimerId);

/**********************************************************************************************************
 * Description : Interface Function to set preload to start counting from this value
 * Outputs     : void
 * Inputs      : Timer ID, Preload value
 ***********************************************************************************************************/
void TIMER_vSetPreload		(u8 A_u8TimerId, u8 A_u8PreloadVal);

/**********************************************************************************************************
 * Description : Interface Function to set OCR register to be used in CTC mode
 * Outputs     : void
 * Inputs      : Timer ID, OCR value
 ***********************************************************************************************************/
void TIMER_vSetOcrVal		(u8 A_u8TimerId, u8 A_u8OcrVal);

/**********************************************************************************************************
 * Description : Interface Function to set the call back function that will be executed during overflow
 * Outputs     : void
 * Inputs      : Timer ID, pointer to function
 ***********************************************************************************************************/
void TIMER_vCallBack_OVF	(ptr_func_t ptr, u8 A_u8TimerId);

/**********************************************************************************************************
 * Description : Interface Function to set the call back function that will be executed during CTC
 * Outputs     : void
 * Inputs      : Timer ID, pointer to function
 ***********************************************************************************************************/
void TIMER_vCallBack_CTC	(ptr_func_t ptr, u8 A_u8TimerId);

/**********************************************************************************************************
 * Description : Interface Function to set a delay for a specific timer
 * Outputs     : void
 * Inputs      : Timer ID, required delay in milliseconds, the function to be executed
 ***********************************************************************************************************/
void  TIMER_vDelayMilli (u16 A_u8DelayMs, u8 A_u8TimerId, ptr_func_t ptr);

void TIMER_vSetDutyCycle	(u8 A_u8TimerId, u8 A_u8DutyCycle);


#endif /* MCAL_TIMER_TIMER_INT_H_ */
