/*********************************************************/
/***********		Author: TaqiEldeen	 	**************/
/***********		Layer: MCAL			 	**************/
/***********		Component: TIMER		**************/
/***********		Version: 1.00		 	**************/
/***********		Date: 13 Sep 2022	 	**************/
/*********************************************************/
#ifndef MCAL_TIMER_TIMER_REG_H_
#define MCAL_TIMER_TIMER_REG_H_

/**************   Timer0 Registers   **************/
/*Register TCCR0*/
#define TCCR0 *((volatile u8*) 0x53)
/*Pins*/
#define CS00  0 /*Clock select*/
#define CS01  1 /*Clock select*/
#define CS02  2 /*Clock select*/
#define WGM01 3 /*Waveform gen mode*/
#define COM00 4 /*OC0 pin MODES*/
#define COM01 5 /*OC0 pin MODES*/
#define WGM00 6 /*Waveform gen mode*/
#define FOC0  7 /*Force output compare*/

/*Register TCCR2*/
#define TCCR2 *((volatile u8*) 0x45)
/*Pins*/
#define CS20	0
#define CS21	1
#define CS22	2
#define WGM21	3
#define COM20	4
#define COM21	5
#define WGM20	6
#define FOC2	7

/*register TCNTn timer counter*/
#define TCNT0 *((volatile u8*) 0x52)
#define TCNT2 *((volatile u8*) 0x44)

/*Register OCRn*/
#define OCR0  *((volatile u8*) 0x5C)
#define OCR2  *((volatile u8*) 0x43)

/*Register TIMSK*/
#define TIMSK *((volatile u8*) 0x59)

/*Pins*/
#define TOIE0  0
#define OCIE0  1
#define TOIE1  2
#define OCIE1B 3
#define OCIE1A 4
#define TICIE1 5
#define TOIE2  6
#define OCIE2  7

/*Register TIFR*/
#define TIFR  *((volatile u8*) 0x58)

/*Pins*/
#define TOV0  0
#define OCF0  1
#define TOV1  2
#define OCF1B 3
#define OCF1A 4
#define ICF1  5
#define TOV2  6
#define OCF2  7

#endif /* MCAL_TIMER_TIMER_REG_H_ */
