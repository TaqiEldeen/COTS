/*********************************************************/
/***********		Author: TaqiEldeen	 	**************/
/***********		Layer: MCAL			 	**************/
/***********		Component: TIMER		**************/
/***********		Version: 1.00		 	**************/
/***********		Date: 13 Sep 2022	 	**************/
/*********************************************************/

#include "../../LIB/STD_TYPES.h"
#include "../../LIB/BIT_MATH.h"
#include "../DIO/DIO_int.h"
#include <math.h>

#include "../TIMER/TIMER_cfg.h"
#include "../TIMER/TIMER_int.h"
#include "../TIMER/TIMER_pri.h"
#include "../TIMER/TIMER_reg.h"


/**********************************************************************************************************
 * Description : Interface Function to 1-Timer mode select, 2-Set OCn Pin state, 3-Disable force o/p compare, 4- enable interrupt
 * Outputs     : void
 * Inputs      : Timer ID
 ***********************************************************************************************************/
void TIMER_vInit (){
#if TIMER0_STATE == TIMER_ENABLE
	/*Step 1: Choose timer mode*/
	#if TIMER0_WGM_MODE == TIMER0_WGM_NORMAL_MODE
		TCCR0 &= TIMER0_WGM_MASK;
		TCCR0 |= TIMER0_WGM_MODE;

		/*Set the interrupt*/
		#if TIMER0_OVF_INT_STATE == INT_ENABLE
			SET_BIT(TIMSK, TOIE0);
		#endif

	#elif TIMER0_WGM_MODE == TIMER0_WGM_CTC_MODE
		TIMER_vTimer0_SetupCTC();
	#elif TIMER0_WGM_MODE == TIMER0_WGM_FAST_PWM_MODE
		TIMER_vTimer0_SetupFastPWM();
	#elif TIMER0_WGM_MODE == TIMER0_WGM_PWM_PHASE_CORRECT_MODE
		TIMER_vTimer0_SetupPhaseCorrectPWM();
	#endif

	/*Disable force output compare by default*/
	CLR_BIT(TCCR0, FOC0);

#else
	TCCR0 &= TIMER0_CLK_SELECT_MASK;
	TCCR0 |= TIMER0_PRESCALER_NO_CLK;
#endif



#if TIMER1_STATE == TIMER_ENABLE
#else
#endif



#if TIMER2_STATE == TIMER_ENABLE
	/*Step 1: Choose timer mode*/
	#if TIMER2_WGM_MODE == TIMER2_WGM_NORMAL_MODE
		TCCR0 &= TIMER0_WGM_MASK;
		TCCR0 |= TIMER0_WGM_MODE;

		/*Set the interrupt*/
		#if TIMER2_OVF_INT_STATE == INT_ENABLE
			SET_BIT(TIMSK, TOIE0);
		#endif

	#elif TIMER2_WGM_MODE == TIMER2_WGM_CTC_MODE
		TIMER_vTimer2_SetupCTC();
	#elif TIMER2_WGM_MODE == TIMER2_WGM_FAST_PWM_MODE
		TIMER_vTimer2_SetupFastPWM();
	#elif TIMER2_WGM_MODE == TIMER2_WGM_PWM_PHASE_CORRECT_MODE
		TIMER_vTimer2_SetupPhaseCorrectPWM();
	#endif

	/*Disable force output compare by default*/
	CLR_BIT(TCCR2, FOC2);
#else
#endif

	return;
}

/**********************************************************************************************************
 * Description : Interface Function to Turn on timer
 * Outputs     : void
 * Inputs      : Timer ID
 ***********************************************************************************************************/
void TIMER_vTurnOn (u8 A_u8TimerId){
	switch(A_u8TimerId){
		case TIMER0_ID:
			TCCR0 &= TIMER0_CLK_SELECT_MASK;
			TCCR0 |= TIMER0_CLK_SELECT;
			break;
		case TIMER1_ID:
			break;
		case TIMER2_ID:
			TCCR2 &= TIMER2_CLK_SELECT_MASK;
			TCCR2 |= TIMER2_CLK_SELECT;
			break;
	}

	return;
}

/**********************************************************************************************************
 * Description : Interface Function to Turn off timer
 * Outputs     : void
 * Inputs      : Timer ID
 ***********************************************************************************************************/
void TIMER_vTurnOff	(u8 A_u8TimerId){
	switch(A_u8TimerId){
		case TIMER0_ID:
			TCCR0 &= TIMER0_CLK_SELECT_MASK;
			TCCR0 |= TIMER0_PRESCALER_NO_CLK;
			break;
		case TIMER1_ID:
			break;
		case TIMER2_ID:
			TCCR2 &= TIMER2_CLK_SELECT_MASK;
			TCCR2 |= TIMER2_PRESCALER_NO_CLK;
			break;
	}

	return;
}

/**********************************************************************************************************
 * Description : Interface Function to set preload to start counting from this value
 * Outputs     : void
 * Inputs      : Timer ID, Preload value
 ***********************************************************************************************************/
void TIMER_vSetPreload (u8 A_u8TimerId, u8 A_u8PreloadVal){
	switch(A_u8TimerId){
		case TIMER0_ID:
			TCNT0 = A_u8PreloadVal;
			G_u8Timer0_Preload_Val = A_u8PreloadVal;
			break;
		case TIMER1_ID:
			break;
		case TIMER2_ID:
			TCNT2 = A_u8PreloadVal;
			G_u8Timer2_Preload_Val = A_u8PreloadVal;
			break;
	}

	return;
}

/**********************************************************************************************************
 * Description : Interface Function to set OCR register to be used in CTC mode
 * Outputs     : void
 * Inputs      : Timer ID, OCR value
 ***********************************************************************************************************/
void TIMER_vSetOcrVal (u8 A_u8TimerId, u8 A_u8OcrVal){
	switch(A_u8TimerId){
		case TIMER0_ID: OCR0 = A_u8OcrVal; break;
		case TIMER1_ID: break;
		case TIMER2_ID: OCR2 = A_u8OcrVal; break;
	}
	return;
}

/**********************************************************************************************************
 * Description : Interface Function to set the call back function that will be executed during overflow
 * Outputs     : void
 * Inputs      : Timer ID, pointer to function
 ***********************************************************************************************************/
void TIMER_vCallBack_OVF (ptr_func_t ptr, u8 A_u8TimerId){
	switch(A_u8TimerId){
		case TIMER0_ID: G_PTRF_TIM0_OVF = ptr; break;
		case TIMER1_ID: break;
		case TIMER2_ID: G_PTRF_TIM2_OVF = ptr; break;
	}
	return;
}

/**********************************************************************************************************
 * Description : Interface Function to set the call back function that will be executed during CTC
 * Outputs     : void
 * Inputs      : Timer ID, pointer to function
 ***********************************************************************************************************/
void TIMER_vCallBack_CTC (ptr_func_t ptr, u8 A_u8TimerId){
	switch(A_u8TimerId){
		case TIMER0_ID: G_PTRF_TIM0_CTC = ptr; break;
		case TIMER1_ID: break;
		case TIMER2_ID: G_PTRF_TIM2_CTC = ptr; break;
	}
	return;
}


/**********************************************************************************************************
 * Description : Interface Function to set a delay for a specific timer
 * Outputs     : void
 * Inputs      : Timer ID, required delay in milliseconds, the function to be executed
 ***********************************************************************************************************/
void  TIMER_vDelayMilli (u16 A_u16DelayMs, u8 A_u8TimerId, ptr_func_t ptr){
	u16 L_u16PrescaleVal = 1;
	f32 L_f32TimeOverFlow;
	f32 L_f32TickTime;
	u16 L_u16OverFlowCounts = 0;
	u16 L_u8PreloadVal = 0;

	switch(TIMER0_CLK_SELECT){
		case TIMER0_PRESCALER_8:    L_u16PrescaleVal = 8; 	break;
		case TIMER0_PRESCALER_64:   L_u16PrescaleVal = 16; 	break;
		case TIMER0_PRESCALER_256:  L_u16PrescaleVal = 256; break;
		case TIMER0_PRESCALER_1024: L_u16PrescaleVal = 1024;break;
	}

	/*Tick time Calculation*/
	L_f32TickTime = (f32)L_u16PrescaleVal / TIMER0_InputFreq;

	/*Time required for complete 1 over flow*/
	L_f32TimeOverFlow = TIMER0_MAX_COUNT * (L_f32TickTime * ((u16)1000));

	/*Over flow needed by this delay*/
	L_u16OverFlowCounts = (u16)ceil(( ((f32)A_u16DelayMs /L_f32TimeOverFlow) ));

	/*Calculating OverFlow counts & preload value*/
	L_u8PreloadVal = (f32)L_u16OverFlowCounts - ((f32)A_u16DelayMs /L_f32TimeOverFlow);
	G_u16Timer0_Cov = L_u16OverFlowCounts;


#if  TIMER0_WGM_MODE == TIMER0_WGM_CTC_MODE
		TIMER_vSetOcrVal(TIMER0_ID, (TIMER0_MAX_COUNT - L_u8PreloadVal));
		G_PTRF_TIM0_CTC = ptr;
#elif TIMER0_WGM_MODE == TIMER0_WGM_NORMAL_MODE
		G_PTRF_TIM0_OVF = ptr;
#endif


}




/**************   TIMER0 mode functions   **************/

static void TIMER_vTimer0_SetupCTC(){
	/*Setup the mode*/
	TCCR0 &= TIMER0_WGM_MASK;
	TCCR0 |= TIMER0_WGM_MODE;

	/*Setup the OC0 Pin*/
	TCCR0 &= TIMER0_COM_MASK;
	TCCR0 |= TIMER0_OC0_MODE;

	#if TIMER0_OC0_MODE == TIMER0_OC0_DISCONNECT

	#else
		/*Must set the OC0 pin output if in CTC, fast PWM or phase correct PWM modes*/
		DIO_vSetPinDir(OC0_PORT, OC0_PIN, DIR_OUTPUT);
	#endif

	#if TIMER0_CTC_INT_STATE == INT_ENABLE
		SET_BIT(TIMSK, OCIE0);
	#endif

	return;
}

static void TIMER_vTimer0_SetupFastPWM	(){
	TCCR0 &= TIMER0_WGM_MASK;
	TCCR0 |= TIMER0_WGM_MODE;

	/*Step 2: Setup the OC0 Pin*/
	#if TIMER0_PWM_MODE == PWM_INVERTING
		SET_BIT(TCCR0, COM00);
		SET_BIT(TCCR0, COM01);
	#elif TIMER0_PWM_MODE == PWM_NON_INVERTING
		CLR_BIT(TCCR0, COM00);
		SET_BIT(TCCR0, COM01);
	#else

	#endif

	/*Calculate the dutyCycle*/
	TIMER_vSetDutyCycle(TIMER0_ID, TIMER0_DUTY_CYCLE);
	/*Must set the OC0 pin output if in CTC, fast PWM or phase correct PWM modes*/
	DIO_vSetPinDir(OC0_PORT, OC0_PIN, DIR_OUTPUT);

	return;
}

static void TIMER_vTimer0_SetupPhaseCorrectPWM	(){
	TCCR0 &= TIMER0_WGM_MASK;
	TCCR0 |= TIMER0_WGM_MODE;

	/*Step 2: Setup the OC0 Pin*/
	#if TIMER0_PWM_MODE == PWM_INVERTING
		SET_BIT(TCCR0, COM00);
		SET_BIT(TCCR0, COM01);
	#elif TIMER0_PWM_MODE == PWM_NON_INVERTING
		CLR_BIT(TCCR0, COM00);
		SET_BIT(TCCR0, COM01);
	#else

	#endif

	/*Must set the OC0 pin output if in CTC, fast PWM or phase correct PWM modes*/
	DIO_vSetPinDir(OC0_PORT, OC0_PIN, DIR_OUTPUT);

	return;
}





/**************   TIMER2 mode functions   **************/

static void TIMER_vTimer2_SetupCTC(){
	/*Setup the mode*/
	TCCR2 &= TIMER2_WGM_MASK;
	TCCR2 |= TIMER2_WGM_MODE;

	/*Setup the OC0 Pin*/
	TCCR2 &= TIMER2_COM_MASK;
	TCCR2 |= TIMER2_OC0_MODE;

	#if TIMER2_OC0_MODE == TIMER2_OC2_DISCONNECT

	#else
		/*Must set the OC2 pin output if in CTC, fast PWM or phase correct PWM modes*/
		DIO_vSetPinDir(OC2_PORT, OC2_PIN, DIR_OUTPUT);
	#endif

	#if TIMER2_CTC_INT_STATE == INT_ENABLE
		SET_BIT(TIMSK, OCIE2);
	#endif

	return;
}

static void TIMER_vTimer2_SetupFastPWM	(){
	TCCR2 &= TIMER2_WGM_MASK;
	TCCR2 |= TIMER2_WGM_MODE;

	/*Step 2: Setup the OC0 Pin*/
	#if TIMER2_PWM_MODE == PWM_INVERTING
		SET_BIT(TCCR2, COM20);
		SET_BIT(TCCR2, COM21);
	#elif TIMER2_PWM_MODE == PWM_NON_INVERTING
		CLR_BIT(TCCR2, COM20);
		SET_BIT(TCCR2, COM21);
	#else

	#endif

	/*Calculate the dutyCycle*/
	TIMER_vSetDutyCycle(TIMER2_ID, TIMER2_DUTY_CYCLE);
	/*Must set the OC2 pin output if in CTC, fast PWM or phase correct PWM modes*/
	DIO_vSetPinDir(OC2_PORT, OC2_PIN, DIR_OUTPUT);

	return;
}

static void TIMER_vTimer2_SetupPhaseCorrectPWM	(){
	TCCR2 &= TIMER2_WGM_MASK;
	TCCR2 |= TIMER2_WGM_MODE;

	/*Step 2: Setup the OC0 Pin*/
	#if TIMER2_PWM_MODE == PWM_INVERTING
		SET_BIT(TCCR2, COM00);
		SET_BIT(TCCR2, COM01);
	#elif TIMER2_PWM_MODE == PWM_NON_INVERTING
		CLR_BIT(TCCR2, COM20);
		SET_BIT(TCCR2, COM21);
	#else

	#endif

	/*Calculate the dutyCycle*/
	TIMER_vSetDutyCycle(TIMER2_ID, TIMER2_DUTY_CYCLE);
	/*Must set the OC2 pin output if in CTC, fast PWM or phase correct PWM modes*/
	DIO_vSetPinDir(OC2_PORT, OC2_PIN, DIR_OUTPUT);

	return;
}




void TIMER_vSetDutyCycle (u8 A_u8TimerId, u8 A_u8DutyCycle){
	switch(A_u8TimerId){
		case TIMER0_ID:
			#if TIMER0_PWM_MODE == PWM_NON_INVERTING
				TIMER_vSetOcrVal(TIMER0_ID, (TIMER0_MAX_COUNT * A_u8DutyCycle ) /100);
			#elif TIMER0_PWM_MODE == PWM_INVERTING
				TIMER_vSetOcrVal(TIMER0_ID, (TIMER0_MAX_COUNT * A_u8DutyCycle ) /100);
			#endif
			break;
		case TIMER1_ID: break;
		case TIMER2_ID:
			#if TIMER2_PWM_MODE == PWM_NON_INVERTING
				TIMER_vSetOcrVal(TIMER2_ID, (TIMER2_MAX_COUNT * A_u8DutyCycle ) /100);
			#elif TIMER2_PWM_MODE == PWM_INVERTING
				TIMER_vSetOcrVal(TIMER2_ID, ( -1 * (TIMER2_MAX_COUNT * ( (A_u8DutyCycle / 100) - 1) ) ));
			#endif
			break;
	}

	return;
}


/**************   TIMER0 ISR   **************/


/*TIMER0 COMP*/
void __vector_10(void){
	if(G_PTRF_TIM0_CTC != ADDRESS_NULL){
		G_PTRF_TIM0_CTC();
	} else {
		/*Handle callback error*/
	}
}

/*TIMER0 OVF*/
void __vector_11(void){
	static u16 L_u16Counter = 0;
	if(G_PTRF_TIM0_OVF != ADDRESS_NULL){
		if(L_u16Counter == G_u16Timer0_Cov) {
			L_u16Counter = 0;
			TCNT0 = G_u8Timer0_Preload_Val;
			G_PTRF_TIM0_OVF();
		} else {
			L_u16Counter++;
		}
	} else {
		/*Handle callback error*/
	}
	return;
}


/**************   TIMER2 ISR   **************/

/*TIMER2 COMP*/
void __vector_4(void){
	if(G_PTRF_TIM2_CTC != ADDRESS_NULL){
		G_PTRF_TIM2_CTC();
	} else {
		/*Handle callback error*/
	}
}

/*TIMER2 OVF*/
void __vector_5(void){

}
